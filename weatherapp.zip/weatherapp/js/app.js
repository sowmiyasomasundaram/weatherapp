'use strict';

var myapp = angular.module('myapp', []);
myapp.controller('WeatherCtrl', function ($http, $scope) {                 
        $http.jsonp('http://api.openweathermap.org/data/2.5/forecast?q=Melbourne,at&units=metric&cnt=40&callback=JSON_CALLBACK&APPID=43c1298d3cad2fb599a59a1e4e181754').success(function(data) {
            console.log(data);
            var result = [];
            for(var i=0; i<data.list.length; i++){   
                var splitVal = data.list[i].dt_txt.split(" ");
                var time =splitVal[0];
                var splitValTime = splitVal[1];
                if(splitValTime == "12:00:00"){
                    var baseUrl = 'https://ssl.gstatic.com/onebox/weather/128/';
                    var iconUrl = data.list[i].main.humidity;
                    if (iconUrl < 20) {
                        baseUrl += 'sunny.png';                    
                    } else if (iconUrl <= 80) {
                       baseUrl += 'partly_cloudy.png';                    
                    } else {
                        baseUrl += 'cloudy.png';                        
                    }
                    result.push({
                        "Date": time,
                        "Humidity": data.list[i].main.humidity,
                        "icon" : baseUrl,
                        "Max_Temp": data.list[i].main.temp_max,
                        "Min_Temp": data.list[i].main.temp_min});
                }
            }
            $scope.forecastValues = result;
        });
      
});
